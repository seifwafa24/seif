<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Product;
class ProductController extends Controller{

    public function index(){
        $products = Product::all();
        return response()->json(['message' => 'Success' ,
            'data' => $products
        ]);
    }

    public function store(Request $request){
        $product = Product::create($request->all());
        return response()->json([
            'message' => 'Data Inserted' ,
            'data' => $product
        ]);
    }//store
   
    public function show(Product $product){
        return response()->json([
            'message' => 'Success' ,
            'data' => $product
        ]);
    } //show

    public function update(Request $request, Product $product){
        $product ->update($request->all());
        return response()->json([
            'message' => 'Data Updateed' ,
            'data' => $product
        ]);
    }
    
    public function destroy(Product $product)
    {
        $product ->delete();
        return response()->json([
            'message' => 'Data Deleted' ,
            'data' => null
        ]);
    }
}
